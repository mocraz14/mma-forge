import { useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Ionicons } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import { theme } from '../lib/theme';

export function VideoPlayer({ youtubeId, height = 220 }: { youtubeId: string; height?: number }) {
  const [error, setError] = useState(false);

  if (error) {
    return (
      <View style={[styles.fallback, { height }]}>
        <Ionicons name="cloud-offline-outline" size={36} color={theme.colors.textMuted} />
        <Text style={styles.fallbackText}>Video unavailable offline</Text>
        <Pressable
          style={styles.openBtn}
          onPress={() => Linking.openURL(`https://www.youtube.com/watch?v=${youtubeId}`)}
        >
          <Text style={styles.openText}>Open in YouTube</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.wrap}>
      <YoutubePlayer
        height={height}
        videoId={youtubeId}
        onError={() => setError(true)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { borderRadius: 12, overflow: 'hidden', backgroundColor: '#000' },
  fallback: {
    backgroundColor: theme.colors.surface,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  fallbackText: { color: theme.colors.textMuted, fontSize: 13 },
  openBtn: {
    marginTop: 6,
    backgroundColor: theme.colors.accent,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 6,
  },
  openText: { color: '#fff', fontWeight: '700' },
});
