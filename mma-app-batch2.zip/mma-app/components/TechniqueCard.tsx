import { View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { theme } from '../lib/theme';
import type { Technique } from '../data';

export function TechniqueCard({ t, isFavorite, onToggleFavorite }: {
  t: Technique;
  isFavorite?: boolean;
  onToggleFavorite?: () => void;
}) {
  const levelColor =
    t.level === 'beginner' ? theme.colors.success
    : t.level === 'intermediate' ? theme.colors.gold
    : theme.colors.accent;

  return (
    <Pressable
      style={({ pressed }) => [styles.card, pressed && { opacity: 0.7 }]}
      onPress={() => router.push(`/technique/${t.id}`)}
    >
      <View style={styles.row}>
        <View style={styles.thumb}>
          <Ionicons name="play-circle" size={32} color={theme.colors.accent} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.title} numberOfLines={2}>{t.title}</Text>
          <Text style={styles.coach}>{t.coach} · {t.subcategory}</Text>
          <View style={styles.meta}>
            <View style={[styles.badge, { borderColor: levelColor }]}>
              <Text style={[styles.badgeText, { color: levelColor }]}>{t.level}</Text>
            </View>
            <Text style={styles.duration}>{t.duration}</Text>
          </View>
        </View>
        {onToggleFavorite && (
          <Pressable onPress={onToggleFavorite} hitSlop={12}>
            <Ionicons
              name={isFavorite ? 'heart' : 'heart-outline'}
              size={22}
              color={isFavorite ? theme.colors.accent : theme.colors.textMuted}
            />
          </Pressable>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  thumb: {
    width: 56, height: 56, borderRadius: 8,
    backgroundColor: theme.colors.bg,
    alignItems: 'center', justifyContent: 'center',
  },
  title: { color: theme.colors.text, fontSize: 15, fontWeight: '700' },
  coach: { color: theme.colors.textMuted, fontSize: 12, marginTop: 2 },
  meta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6 },
  badge: { borderWidth: 1, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  badgeText: { fontSize: 10, fontWeight: '700', textTransform: 'uppercase' },
  duration: { color: theme.colors.textMuted, fontSize: 11 },
});
