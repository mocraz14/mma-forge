export { striking } from './striking';
export { grappling } from './grappling';
export { conditioning } from './conditioning';
export { drills } from './drills';
export type { Technique } from './striking';

import { striking } from './striking';
import { grappling } from './grappling';
import { conditioning } from './conditioning';
import { drills } from './drills';

export const allTechniques = [...striking, ...grappling, ...conditioning, ...drills];

export const getById = (id: string) => allTechniques.find(t => t.id === id);
