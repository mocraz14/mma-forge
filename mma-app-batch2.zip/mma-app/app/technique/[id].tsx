import { useEffect, useState } from 'react';
import { ScrollView, View, Text, StyleSheet, Pressable } from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { getById } from '../../data';
import { VideoPlayer } from '../../components/VideoPlayer';
import { theme } from '../../lib/theme';
import { storage } from '../../lib/storage';

export default function TechniqueDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const t = getById(id!);
  const [fav, setFav] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!t) return;
    (async () => {
      const favs = await storage.get<string[]>('favorites', []);
      setFav(favs.includes(t.id));
      const completed = await storage.get<string[]>('completed', []);
      setDone(completed.includes(t.id));
    })();
  }, [t?.id]);

  if (!t) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: theme.colors.text }}>Technique not found.</Text>
      </View>
    );
  }

  const toggleFav = async () => {
    const list = await storage.toggleInSet('favorites', t.id);
    setFav(list.includes(t.id));
  };

  const markDone = async () => {
    const list = await storage.toggleInSet('completed', t.id);
    setDone(list.includes(t.id));
  };

  return (
    <>
      <Stack.Screen options={{ title: t.subcategory, headerBackTitle: 'Back' }} />
      <ScrollView style={styles.container} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        <VideoPlayer youtubeId={t.youtubeId} />

        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>{t.title}</Text>
            <Text style={styles.coach}>Taught by {t.coach}</Text>
          </View>
          <Pressable onPress={toggleFav} hitSlop={10}>
            <Ionicons name={fav ? 'heart' : 'heart-outline'} size={26}
              color={fav ? theme.colors.accent : theme.colors.textMuted} />
          </Pressable>
        </View>

        <Text style={styles.body}>{t.description}</Text>

        <Section title="Key Points" items={t.keyPoints} icon="checkmark-circle" color={theme.colors.success} />
        <Section title="Common Mistakes" items={t.commonMistakes} icon="close-circle" color={theme.colors.accent} />

        <Pressable onPress={markDone} style={[styles.cta, done && { backgroundColor: theme.colors.success }]}>
          <Ionicons name={done ? 'checkmark-done' : 'checkmark'} size={20} color="#fff" />
          <Text style={styles.ctaText}>{done ? 'Completed' : 'Mark as Practised'}</Text>
        </Pressable>
      </ScrollView>
    </>
  );
}

function Section({ title, items, icon, color }: any) {
  return (
    <View style={{ marginTop: 18 }}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {items.map((item: string, i: number) => (
        <View key={i} style={styles.item}>
          <Ionicons name={icon} size={16} color={color} style={{ marginTop: 2 }} />
          <Text style={styles.itemText}>{item}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', marginTop: 16, gap: 12 },
  title: { color: theme.colors.text, fontSize: 20, fontWeight: '800' },
  coach: { color: theme.colors.gold, fontSize: 13, marginTop: 2 },
  body: { color: theme.colors.textMuted, fontSize: 14, lineHeight: 20, marginTop: 10 },
  sectionTitle: {
    color: theme.colors.text, fontSize: 16, fontWeight: '700',
    marginBottom: 8, textTransform: 'uppercase', letterSpacing: 1,
  },
  item: { flexDirection: 'row', gap: 8, marginBottom: 6 },
  itemText: { color: theme.colors.text, fontSize: 14, flex: 1, lineHeight: 20 },
  cta: {
    marginTop: 24, backgroundColor: theme.colors.accent,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, padding: 14, borderRadius: 10,
  },
  ctaText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
